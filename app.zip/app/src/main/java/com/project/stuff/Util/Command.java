package com.project.stuff.Util;

/**
 * Created by jasonbakthakumar on 27/01/17.
 */

public class Command {

    public String voiceCommand;
    public int whoseIsIt;

    public Command(String voiceCommand, int whoseIsIt) {
        this.voiceCommand = voiceCommand;
        this.whoseIsIt = whoseIsIt;
    }

    public String getVoiceCommand() {
        return voiceCommand;
    }

    public void setVoiceCommand(String voiceCommand) {
        this.voiceCommand = voiceCommand;
    }

    public int getWhoseIsIt() {
        return whoseIsIt;
    }

    public void setWhoseIsIt(int whoseIsIt) {
        this.whoseIsIt = whoseIsIt;
    }
}
