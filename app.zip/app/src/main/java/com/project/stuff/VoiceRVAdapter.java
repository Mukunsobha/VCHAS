package com.project.stuff;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.project.stuff.Util.Command;

import java.util.List;

/**
 * Created by jasonbakthakumar on 27/01/17.
 */

public class VoiceRVAdapter extends RecyclerView.Adapter<VoiceRVAdapter.MyViewHolder>  {


    private List<Command> commandList;

    public VoiceRVAdapter(List<Command> commandList) {
        this.commandList = commandList;
    }


    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.command_stuff, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        Command command = commandList.get(position);
        holder.textView.setText(command.getVoiceCommand());
        if(command.getWhoseIsIt() == 0){
            holder.textView.setGravity(Gravity.END);
            holder.textView.setTextColor(Color.BLUE);
        }
        else{
            holder.textView.setGravity(Gravity.START);
        }
    }

    

    @Override
    public int getItemCount() {
        return commandList.size();
    }

    public void addNewItem(Command command) {
        commandList.add(command);
        notifyItemInserted(commandList.size());
    }


    public class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView textView;

        public MyViewHolder(View view) {
            super(view);
            textView = (TextView) view.findViewById(R.id.textView2);
        }
    }

}
