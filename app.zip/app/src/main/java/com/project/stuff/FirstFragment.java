package com.project.stuff;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.project.stuff.Util.Command;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;

/**
 * Created by jasonbakthakumar on 27/01/17.
 */

public class FirstFragment extends Fragment {

    FloatingActionButton button;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    RecyclerView rvVoice;
    VoiceRVAdapter adapter;
    public FirstFragment() {

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_one, container, false);
        button = (FloatingActionButton) rootView.findViewById(R.id.floatingActionButton2);
        rvVoice = (RecyclerView) rootView.findViewById(R.id.rvCommand);
        List<Command>  list= new ArrayList<>();
        Command command = new Command("Welcome, Speak your Command",0);
        list.add(command);
        adapter = new VoiceRVAdapter(list);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        rvVoice.setLayoutManager(mLayoutManager);
        rvVoice.setAdapter(adapter);
        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
        loginDetails.edit().putInt("app",10).apply();
        return rootView;
    }


    @Override
    public void onResume() {
        super.onResume();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                promptSpeechInput();
            }
        });

    }

    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,
                getString(R.string.speech_prompt));
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getActivity(),"Text to speech not supported",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {
                    ArrayList<String> result = data
                            .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    adapter.addNewItem(new Command(result.get(0),0));
                    String testString = result.get(0);
                    if(testString.contains("on") && testString.contains("light")){
                        adapter.addNewItem(new Command("Switching On The Light",1));
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        loginDetails.edit().putInt("app",0).apply();
                    }
                    else if(testString.contains("on") && testString.contains("fan")){
                        adapter.addNewItem(new Command("Switching On The Fan",1));
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        loginDetails.edit().putInt("app",1).apply();

                    }
                    else if(testString.contains("on") && testString.contains("alarm")){
                        adapter.addNewItem(new Command("Switching On The Alarm",1));
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        loginDetails.edit().putInt("app",2).apply();

                    }
                    else if(testString.contains("on") && testString.contains("coffee")){
                        adapter.addNewItem(new Command("I'm preparing coffee for you",1));
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        loginDetails.edit().putInt("app",3).apply();
                    }
                    else if(testString.contains("of") && testString.contains("light")){
                        adapter.addNewItem(new Command("Switching Off The Light",1));
                    }
                    else if(testString.contains("of") && testString.contains("fan")){
                        adapter.addNewItem(new Command("Switching Off The Fan",1));

                    }
                    else if(testString.contains("of") && testString.contains("alarm")){
                        adapter.addNewItem(new Command("Switching Off The Alarm",1));

                    }
                    else if(testString.contains("of") && testString.contains("coffee")){
                        adapter.addNewItem(new Command("Alright, I stopped making coffee",1));
                    }
                    else if(testString.contains("it") && testString.contains("of")){
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        switch (loginDetails.getInt("app",10)){
                            case 0:
                                adapter.addNewItem(new Command("Switching Off The Light",1));
                                break;

                            case 1:
                                adapter.addNewItem(new Command("Switching Off The Fan",1));
                                break;

                            case 2:
                                adapter.addNewItem(new Command("Switching Off The Alarm",1));
                                break;

                            case 3:
                                adapter.addNewItem(new Command("Alright, I stopped making coffee",1));
                                break;

                            default:
                                adapter.addNewItem(new Command("Sorry, but you did not mention anything earlier",1));
                                break;

                        }
                    }
                    else if(testString.contains("it") && testString.contains("on")){
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        switch (loginDetails.getInt("app",10)){
                            case 0:
                                adapter.addNewItem(new Command("Switching On The Light",1));
                                break;

                            case 1:
                                adapter.addNewItem(new Command("Switching On The Fan",1));
                                break;

                            case 2:
                                adapter.addNewItem(new Command("Switching On The Alarm",1));
                                break;

                            case 3:
                                adapter.addNewItem(new Command("I'm preparing coffee for you",1));
                                break;

                            default:
                                adapter.addNewItem(new Command("Sorry, but you did not mention anything earlier",1));
                                break;

                        }
                    }
                    else if(testString.contains("how") || testString.contains("what")){
                        SharedPreferences loginDetails = getActivity().getSharedPreferences("LOGIN",MODE_PRIVATE);
                        switch (loginDetails.getInt("app",10)){
                            case 0:
                                adapter.addNewItem(new Command("Your Light is On",1));
                                break;

                            case 1:
                                adapter.addNewItem(new Command("Your fan is On",1));
                                break;

                            case 2:
                                adapter.addNewItem(new Command("Your Alarm is On",1));
                                break;

                            case 3:
                                adapter.addNewItem(new Command("Your Coffee Machine is On",1));
                                break;

                            default:
                                adapter.addNewItem(new Command("No appliances are on",1));
                                break;
                        }
                    }
                    else{
                        adapter.addNewItem(new Command("Sorry, I didn't get that",1));

                    }

                }
                break;
            }
        }
        }


}
