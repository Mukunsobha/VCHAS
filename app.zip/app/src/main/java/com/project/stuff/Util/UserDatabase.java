package com.project.stuff.Util;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jasonbakthakumar on 27/01/17.
 */

public class UserDatabase extends SQLiteOpenHelper {


    private static final String DATABASE_NAME = "userManager";
    private static final int DATABASE_VERSION = 1;
    private static final String TABLE_USERS = "usersTable";
    private static final String USER_EMAIL = "userMail";
    private static final String USER_PASSWORD = "userPassword";

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + USER_EMAIL + " TEXT," + USER_PASSWORD + " TEXT" + ")";
        db.execSQL(CREATE_CONTACTS_TABLE);

    }

    public void addContact(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_EMAIL, user.getEmail()); // User mail
        values.put(USER_PASSWORD, user.getPassword());// User password
        // Inserting Row
        db.insert(TABLE_USERS, null, values);
        db.close(); // Closing database connection
    }

    public boolean isContactPresent(User user) {
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_USERS;
        SQLiteDatabase db = this.getWritableDatabase();
        @SuppressLint("Recycle")
        Cursor cursor = db.rawQuery(selectQuery, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user1 = new User(cursor.getString(0),cursor.getString(1));
                if(user1.getEmail().equals(user.getEmail()) && user1.getPassword().equals(user.getPassword())){
                    return true;
                }
            } while (cursor.moveToNext());
        }
        return false;

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);

        // Create tables again
        onCreate(db);

    }
}
