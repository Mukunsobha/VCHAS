package com.project.stuff;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.project.stuff.Util.User;
import com.project.stuff.Util.UserDatabase;

public class Main2Activity extends AppCompatActivity {

    EditText passwordEditText;
    EditText emailEditText;
    Button createStuff;
    public UserDatabase userDatabase = new UserDatabase(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        emailEditText = (EditText) findViewById(R.id.good);
        passwordEditText = (EditText) findViewById(R.id.great);
        createStuff = (Button) findViewById(R.id.button3);

        createStuff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isValidEmail(emailEditText.getText().toString())) {
                    User user = new User(emailEditText.getText().toString(), passwordEditText.getText().toString());
                    userDatabase.addContact(user);
                    SharedPreferences loginDetails = getSharedPreferences("LOGIN", MODE_PRIVATE);
                    loginDetails.edit().putBoolean("done", true).apply();
                    startActivity(new Intent(Main2Activity.this, MIActivity.class));
                }

                else{
                    Toast.makeText(Main2Activity.this, "Please enter a valid User ID", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }



    public boolean isValidEmail(CharSequence target) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}
