package com.project.stuff;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.project.stuff.Util.User;
import com.project.stuff.Util.UserDatabase;

public class MainActivity extends AppCompatActivity {

    public TextInputLayout emailLayout;
    public  TextInputLayout passwordlayout;
    public EditText emailEdittext;
    public EditText passwordEditText;
    public Button signInButton;
    public Button createNewUserButton;
    public UserDatabase userDatabase = new UserDatabase(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        emailLayout = (TextInputLayout) findViewById(R.id.emailTextLayout);
        emailEdittext = (EditText) findViewById(R.id.emailEditText);
        passwordlayout = (TextInputLayout) findViewById(R.id.passwordEditTextLayout);
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);
        signInButton = (Button) findViewById(R.id.button);
        createNewUserButton = (Button) findViewById(R.id.button2);

    }


    @Override
    protected void onResume() {
        super.onResume();
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isValidEmail(emailEdittext.getText().toString())){
                    emailLayout.setErrorEnabled(false);
                    passwordlayout.setErrorEnabled(false);
                    User user = new User(emailEdittext.getText().toString(),passwordEditText.getText().toString());
                    if(userDatabase.isContactPresent(user)){
                        //valid user
                        SharedPreferences loginDetails = getSharedPreferences("LOGIN",MODE_PRIVATE);
                        loginDetails.edit().putBoolean("done",true).apply();
                        startActivity(new Intent(MainActivity.this,MIActivity.class));
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Invalid User", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    //INVALID EMAIL
                    emailLayout.setErrorEnabled(true);
                    emailLayout.setError("Please enter a valid Email");
                }

            }
        });

        createNewUserButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Main2Activity.class));

            }
        });
    }


    public boolean isValidEmail(CharSequence target) {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}
